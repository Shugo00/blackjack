# 使用部品・出典

個人利用・内輪共有向けの試遊候補．本体Pythonコード，卓・カード・チップの手続き描画，短い合成効果音は本プロジェクトで作成した．BGMは含まない．

効果音はsrc/blackjack/audio.pyで紙の擦れ・着地やチップの接触を模して合成する．4種類ずつの微差を含む．外部の録音素材は使用していない．

- Windows Python 3.12.14：PSFライセンス．
- pygame-ce 2.5.8（Windows），Webランタイムのpygame-ce 2.5.7：LGPL-2.1-or-later．改変なし．Windowsは外部配置の拡張モジュール／DLLを使用．対応する取得済みソースとライセンスをthird_partyへ同梱する．
- PyInstaller 6.22.3：COPYINGの例外条項を含め保持．
- pygbag 0.9.3：MIT．公式テンプレートは共通の固定参考minesweeper-reference/0.1.0-rc2-r1から複製．元コミット0d16936286bd3236802cb11072979831d6adc0e8，元テンプレートSHA-256 42404ac4680640d3898e8a28cdd4bc79624b5b4a34ebdd2c2aac4088ebd956af．
- Noto Sans CJK JP：SIL OFL．同じ固定参考からフォントとOFLを複製．フォントSHA-256 68a3fc98800b2a27b371f2fb79991daf3633bd89309d4ffaa6946fd587f375b5．
- worktime 1.0.0：本プロジェクトの共通計測部品．既存のdocs/WORKLOG.md参照．

third_partyは前作マインスイーパー0.1.0-rc2の保全済み原文・出典・ソースを引き継ぐ．前作名を含む原文は取得当時の参考記録であり，本ゲームの検証結果ではない．同梱ファイルのハッシュは配布manifestに記録する．依存導入の固定版・RECORD照合はdocs/dependencies-local.json．

ブラウザランタイム配信元：https://pygame-web.github.io/cdn/0.9.3/ ．検査では取得済みキャッシュのSHA-256を確認して使用し，CDNの現在の到達性と混同しない．

基本戦略・Hi-Loの出典はdocs/04-strategy-design.md第9節．CPU性格・練習用ベット段階・公開集計による仮想比較は独自設計．投資・賭博収益の推奨ではない．
